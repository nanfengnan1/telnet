### 1. simple telnet client
#### 1.1 support characteristic
         support epoll
         wait to support server
         wait to use readline and history
         wait to support yang module
         wait to use pam
### 2. how to build
----
    make
    make install
